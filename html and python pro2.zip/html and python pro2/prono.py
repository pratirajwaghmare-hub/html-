vola="puja"
print(vola)

a=5
s=6
p=a+s
print(p)
print(a-s)

do=50
po=91
ola=do/po
print(ola)
print(do%po)
print(56**45)
print(456++54)
print(486--85)
print(13//3)

lo=456
ol=2325
lo=lo+11
print(lo)
x=5
x-=5
print(x)
x=x-4
print(x)
y=12
i=56
print(y==i)
print(i!=y)
print(i>y)
print(y>i)
print(i<y)
print(i<=y)
print(y<=i)
print(i>=y)

e=10
f=20
print(e==10 or e<f or x==y)
print(e==10 and e<f and x==y)
print( not f!=20)





