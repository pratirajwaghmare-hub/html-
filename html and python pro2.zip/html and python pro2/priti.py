a=43
b=765
print(a+b)

h="hello pratiraj"
print(h)

string1="Sting"
print('s' in string1)


string2="Sting"
print('S' in string2)

l=[45,98,67,23,76]
print(50 in l)

lol=[45,98,67,23,76]
print(50  not in l)
